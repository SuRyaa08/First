package com.sapi.restsapi;

import com.sapi.restsapi.entity.user;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;




@RestController
public class usercontroller {
	
	@GetMapping("/users")
	public List<user> getAllusers(){
		
		List<user> userlist = new ArrayList<>();
		user u1 = new user(1l,"surya","S", 21,"Male",10,"CSE","a","A",1);
		user u2 = new user(2l,"ramesh","S", 21,"Male",10,"CSE","b","A",1);
		user u3 = new user(3l,"suresh","S", 21,"Male",10,"CSE","c","A",1);

		userlist.add(u1);
		userlist.add(u2);
		userlist.add(u3);
		
		return userlist;

		
		
		
	}

}
